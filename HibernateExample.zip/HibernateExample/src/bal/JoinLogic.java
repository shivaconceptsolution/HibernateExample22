package bal;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.util.*;
public class JoinLogic {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Query q = session.createQuery("select c.coursename,s.sname from Course c left join c.studentino s");
		List lst = q.list();
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			Object rows[]=(Object[])it.next();
			System.out.println(rows[0] + " "+rows[1]);
			
			
		}
       session.close();
       
	}

}
