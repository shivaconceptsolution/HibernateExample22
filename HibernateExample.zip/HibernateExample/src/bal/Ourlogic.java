package bal;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.*;
import org.hibernate.cfg.*;

import dal.Course;
import dal.Stu;
public class Ourlogic {

	public static void main(String args[]){
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Course c = new Course();
		c.setCourseid(1001);
		c.setCoursename("Java");
		Stu s = new Stu();
		s.setRno(1001);
		s.setSname("xyz");
		Stu s1 = new Stu();
		s1.setRno(1002);
		s1.setSname("mno");
		Set st=new HashSet();
		st.add(s);
		st.add(s1);
		c.setStudentino(st);
		Transaction tx = session.beginTransaction();
		session.save(c);
		tx.commit();
		session.close();
		
		
		
	
		
		
	}
}
