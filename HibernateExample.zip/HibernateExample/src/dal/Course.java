package dal;
import java.util.*;
public class Course {
  private int courseid;
  private String coursename;
  private Set studentino;
public int getCourseid() {
	return courseid;
}
public void setCourseid(int courseid) {
	this.courseid = courseid;
}
public Set getStudentino() {
	return studentino;
}
public void setStudentino(Set studentino) {
	this.studentino = studentino;
}
public String getCoursename() {
	return coursename;
}
public void setCoursename(String coursename) {
	this.coursename = coursename;
}
  
  
  
}
